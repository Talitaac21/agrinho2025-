// Variáveis de controle
let agua = 0; // quantidade de água na árvore
const maxAgua = 100; // quantidade máxima de água
let regando = false; // se está regando ou não

function setup() {
  createCanvas(400, 400);
  textAlign(LEFT, TOP);
}

function draw() {
  background(220);

  // Desenho da árvore
  drawArvore();

  // Mostrar a quantidade de água
  fill(0);
  textSize(16);
  text('Água: ' + Math.round(agua) + '/' + maxAgua, 10, 10);

  // Indicação visual de regando
  if (regando) {
    fill(0, 0, 255, 100);
    noStroke();
    ellipse(mouseX, mouseY, 50, 50);
  }

  // Se estiver regando, aumenta a água lentamente
  if (regando && agua < maxAgua) {
    agua += 0.3; // ajuste para uma velocidade mais suave
  }

  // Ajuste da cor da árvore com base na água
  let verdeValor = map(agua, 0, maxAgua, 100, 255);
  fill(34, verdeValor, 34);
}

function drawArvore() {
  // Tronco
  fill(139, 69, 19);
  rect(180, 250, 40, 100);

  // Folhas
  let verde = map(agua, 0, maxAgua, 100, 255);
  fill(0, verde, 0);
  ellipse(200, 200, 100, 100);
}

// Quando o usuário clica na árvore, começa a regar
function mousePressed() {
  if (mouseX > 150 && mouseX < 250 && mouseY > 150 && mouseY < 300) {
    regando = true;
  }
}

// Para de regar quando soltar o botão
function mouseReleased() {
  regando = false;
}

// Botão para resetar a água
function keyPressed() {
  if (key === 'r' || key === 'R') {
    agua = 0;
  }
}


































































































































































